/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*   This program will have the robot move left when it senses higher         */
/*   reflectivity than the threshold (Light maximum reflectivity +            */
/*   Dark maximum reflectivity / 2) and will move to the right when it        */
/*   senses less reflectivity than the threshold.                             */
/*                                                                            */
/*   IMPORTANT: In order for this program to work correctly, the Line         */
/*   Tracker needs to be mounted facing down towards the ground, close        */
/*   to the ground.                                                           */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LineTracker          line          A               
// LeftMotor            motor         1               
// Roller               motor         10              
// Controller1          controller                    
// PotentiometerColor   pot           B               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;
//Variable for the calibration method
//Searches for blue
int pastValue;
//Searches for red
int currentValue;
int num;
int min = 101;
int max = -1;
int threshold;
bool lookRed;


void calibrateRoller () {
  pastValue = LineTracker.reflectivity();
  while (num < 50)
  {

    currentValue = LineTracker.reflectivity();
    if (currentValue > max) {
      max = currentValue;
    }
    if (currentValue < min){
      min = currentValue;
    }
    threshold = (max + min) / 2;
    num++;
    pastValue = currentValue;
        if ((lookRed && (currentValue > threshold) && (pastValue < threshold)) || (!lookRed && (currentValue < threshold) && (pastValue > threshold))) {
      Roller.stop();
      break;
    } else {
      Roller.spin(forward);
    }
    wait(80, msec);
  }

}

int main() 
{
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  //To set which alliance color we are spinning the rollers for
  if (PotentiometerColor.angle(degrees) > 130) {
    lookRed = true;
  } else {
    lookRed = false;
  }

  
  Controller1.ButtonA.pressed(calibrateRoller);
  //Should calibrate the threshold and range
  
  
  

  
}
